//
// Created by Turemurat on 17.09.2021.
//
#include "Game.h"
using namespace std;
int main() {
    start();
    cout<<"1)New Game"<<endl<<"2)Resume Saved"<<endl<<"3)Exit Game"<<endl<<"Write here: ";
    int a;
    cin>>a;
    do{
        Game game;
        if( a==1 ) {game.createHero();game.playGame();}
        else if(a==2) {
            ifstream SavedGame("/Users/d1freez/Downloads/untitled1/saveGame.txt");
            string name;
            int HP,maxHP,level,forUp,attack;
            int exp,money,itemPrice1,itemPrice2;
            int itemPrice3,itemAtt1,itemAtt2,itemAtt3;
            string itemName1,itemName2,itemName3;
            SavedGame>>name>>HP>>attack>>exp>>maxHP>>money>>forUp>>level
            >>itemName1>>itemAtt1>>itemPrice1
            >>itemName2>>itemAtt2>>itemPrice2
            >>itemName3>>itemAtt3>>itemPrice3;
            Character myHero = Character(HP,attack,exp,maxHP,money,forUp,level,name);
            myHero.inventory.addItem(Item(itemName1,itemPrice1,itemAtt1));myHero.inventory.addItem(Item(itemName2,itemPrice2,itemAtt2));myHero.inventory.addItem(Item(itemName3,itemPrice3,itemAtt3));
            game = Game(myHero);
            game.playGame();
        }
        break;
    }while( a!=3 );
    return 0;
}