//
// Created by Turemurat on 18.09.2021.
//
#include <iostream>
#include <algorithm>
#include <vector>
#include <cstdlib>
#include <fstream>
#include <string>
using namespace std;
class Item{
private:
    string type;
    int att;
    int price;
public:
    Item(){
        type="gold";
        price=100;
    }
    Item(string type,int price,int att){
        this->type=type;
        this->price=price;
        this->att=att;
    }
    string getType(){
        return type;
    }
    int getPrice(){
        return price;
    }
    int getAttack(){
        return att;
    }
};
class Inventory{
private:
    vector<Item> items;
    int size;
public:
    Inventory(){
        items = vector<Item>();
        size=0;
    }
    Item getItem(int index){
        return items[index];
    }
    void changeItem(Item item){
        swap(items[0],item);
    }
    void sortInventory() {
        for(int i=0;i<items.size();i++){
            for(int j=i+1;j<items.size();j++){
                if(items[i].getPrice()>items[j].getPrice()){
                    swap(items[i],items[j]);
                }
            }
        }
    }
    void addItem(Item item){
        if(size==3) {
            sortInventory();
            if(items[0].getPrice()<item.getPrice()) changeItem(item);
        }
        else {
            items.push_back(item);
            size++;
        }
    }

};
vector<Item> Vitem;