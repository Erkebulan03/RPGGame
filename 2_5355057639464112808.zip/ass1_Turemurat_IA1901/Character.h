//
// Created by Turemurat on 19.09.2021.
//
#include "Inventory.h"
using namespace std;
class Character{
private:
    int HP ;
    int attack;
    int exp ;
    int maxHP ;
    int gold ;
    int forUp;
    int level;
    string name  ;

public:
    Inventory inventory;
    Character(){
        HP=100;
        attack=10;
        exp=0;
        maxHP=100;
        gold=0;
        forUp=100;
        name="Default";
        inventory = Inventory();
        level=0;
    }

    Character(int hp, int attack, int exp, int maxHp, int gold, int forUp, int level, string name) {
        this->HP = hp;
        this->attack = attack;
        this->exp = exp;
        this->maxHP = maxHp;
        this->gold = gold;
        this->name = name;
        this->forUp = forUp;
        this->level=level;
        inventory = Inventory();
    }

    Character(string name) {
        this->name=name;
        HP=100;
        maxHP=100;
        attack=20;
        exp=0;
        gold=0;
        level=0;
        inventory = Inventory();
        forUp=100;
    }

    Character(int HP,int attack,int exp,int maxHP,int gold,string name) {
        this->HP = HP;
        this->attack = attack;
        this->exp = exp;
        this->maxHP = maxHP;
        this->gold = gold;
        this->name = name;
        forUp = 100;
        level=0;
        inventory = Inventory();
    }

    int getHp() const {
        return HP;
    }

    void setHp(int hp) {
        HP = hp;
    }

    int getAttack() const {
        return attack;
    }

    void setAttack(int attack) {
        Character::attack = attack;
    }

    int getForUp() const {
        return forUp;
    }

    void setForUp(int forUp) {
        Character::forUp = forUp;
    }

    int getLevel() const {
        return level;
    }

    void setLevel(int level) {
        Character::level = level;
    }

    int getExp() const {
        return exp;
    }

    void setExp(int exp) {
        Character::exp = exp;
    }

    int getMaxHp() const {
        return maxHP;
    }

    void setMaxHp(int maxHp) {
        maxHP = maxHp;
    }

    int getgold() const {
        return gold;
    }

    void setgold(int gold) {
        Character::gold = gold;
    }

    const string &getName() const {
        return name;
    }

    void setName(const string &name) {
        Character::name = name;
    }
    void levelUp(){
        maxHP+=maxHP/10;exp=0;attack+=5;HP=maxHP;forUp+=(forUp/2);
    }
};
vector<Character> Venemy;