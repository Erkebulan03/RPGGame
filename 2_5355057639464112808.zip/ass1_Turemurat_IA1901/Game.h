//
// Created by Turemurat on 19.09.2021.
//
#include "Character.h"
class Game{
private:
    Character hero;
public:
    Game(){
        hero = Character();
    }
    const Character &getHero() const {
        return hero;
    }

    Game( Character newHero){
        hero = Character(newHero.getHp(),newHero.getAttack(),newHero.getExp(),newHero.getMaxHp(),newHero.getgold(),newHero.getName());
    }

    void createHero(){
        cout<<"Enter Character's name: ";
        string name;
        cin>>name;
        hero = Character(name);
        hero.inventory.addItem(Vitem[0]);
        hero.inventory.addItem(Vitem[1]);
        hero.inventory.addItem(Vitem[2]);
    }
    void playGame(){
        if(hero.getExp()==hero.getForUp()){
            hero.levelUp();
            hero.setLevel(hero.getLevel()+1);
        }
        int y;
        cout<<"1. Explore\n2. Fight\n3. Take a break\n4. Save & quit game\n Enter your choice: ";
        cin>>y;
        if(y==1){
            if(explore())  {hero.setExp(hero.getExp()+10);playGame();}
            else cout<<"You lost,goodbye";
        }
        else if(y==2){
            cout<<"Choose your enemy\n"<<Venemy[0].getName()<<" HP="<<Venemy[0].getHp()<<" Attack="<<Venemy[0].getAttack()<<"\n";
            cout<<Venemy[1].getName()<<" HP="<<Venemy[1].getHp()<<" Attack="<<Venemy[1].getAttack()<<"\n";
            cout<<Venemy[2].getName()<<" HP="<<Venemy[2].getHp()<<" Attack="<<Venemy[2].getAttack()<<"\n";
            cout<<Venemy[3].getName()<<" HP="<<Venemy[3].getHp()<<" Attack="<<Venemy[3].getAttack()<<"\n";
            cout<<Venemy[4].getName()<<" HP="<<Venemy[4].getHp()<<" Attack="<<Venemy[4].getAttack()<<"\n Enter your choice: ";
            int h;
            cin>>h;
            if(fight(Venemy[h])) {hero.setExp(hero.getExp()+15);playGame();}
            else cout<<"You lost";
        }
        else if (y==3){
            hero.setHp(hero.getMaxHp());
            playGame();
        }
        else {
            ofstream mySavedFile ("/Users/d1freez/Downloads/untitled1/saveGame.txt");
            mySavedFile<<hero.getName()<<" "<<hero.getHp()<<" "<<hero.getAttack()<<" "<<hero.getExp()
            <<" "<<hero.getMaxHp()<<" "<<hero.getgold()<<" "<<hero.getForUp()<<" "<<hero.getLevel()<<" "
            <<hero.inventory.getItem(0).getType()<<" "<<hero.inventory.getItem(0).getAttack()<<" "<<hero.inventory.getItem(0).getPrice()<<" "
            <<hero.inventory.getItem(1).getType()<<" "<<hero.inventory.getItem(1).getAttack()<<" "<<hero.inventory.getItem(1).getPrice()<<" "
            <<hero.inventory.getItem(2).getType()<<" "<<hero.inventory.getItem(2).getAttack()<<" "<<hero.inventory.getItem(2).getPrice();
        }
    }
    bool fight(Character enemy){
        bool a=0;
        while(enemy.getHp()>0&&hero.getHp()>0){
            if(a==0) {
                enemy.setHp(enemy.getHp()-hero.getAttack()-hero.inventory.getItem(2).getAttack());a=1;
                cout<<enemy.getName()<<"'s HP is "<<enemy.getHp()<<"\n";
            }
            else {
                hero.setHp(hero.getHp()-enemy.getAttack());a=0;
                cout<<hero.getName()<<"'s HP is "<<hero.getHp()<<"\n";
            }
        }
        if(enemy.getHp()<=0) return true;
        else return false;
    }
    bool explore(){
        int a;
        a = abs(rand()%3);
        if(a == 0){
            int b=abs(rand()%10);
            Item randomItem=Vitem[b];
            hero.inventory.addItem(randomItem);
            return true;
        }
        else if(a == 1){
            hero.setgold(hero.getgold()+abs(rand()%100));
            return true;
        }
        else {
            int b=3;
            Character randomEnemy = Venemy[b];
            return fight(randomEnemy) ;
        }
    }
};
void start(){
    ifstream Items ("/Users/d1freez/Downloads/untitled1/ListOfItems.txt");
    if(Items.is_open()==true){
        int price,att;
        string name;
        int i=0;
        while (i<10){
            Items
            >>name
            >>att
            >>price;
            Item item = Item(name,price,att);
            Vitem.emplace_back(item);
            i++;
        }
        Items.close();
    }
    ifstream Enemies("/Users/d1freez/Downloads/untitled1/enemiesList.txt");
    if (Enemies.is_open()==true){
        int HP,maxHP,att,xp,gold;
        int i=0;
        string name;
        while (i<5){
            Enemies>>name>>HP>>att>>xp>>maxHP>>gold;
            Character enemy = Character(HP,att,xp,maxHP,gold,name);
            Venemy.emplace_back(enemy);
            i++;
        }
        Enemies.close();
    }
}